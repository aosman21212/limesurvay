<div class="selector__toggle_<?=$this->widgetsJsName?>">
    <?=$this->textToDisplay?>
</div>
