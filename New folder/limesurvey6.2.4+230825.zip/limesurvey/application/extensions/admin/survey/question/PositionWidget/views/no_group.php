<div id='Position' class='mb-3'>
    <label class="col-md-4 form-label" for='pos'><?php eT("Position:"); ?></label>
    <div class="col-md-8 text-error">
        <?php eT('No group found!'); ?>
    </div>
</div>
