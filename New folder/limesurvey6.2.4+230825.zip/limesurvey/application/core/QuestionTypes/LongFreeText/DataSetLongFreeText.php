<?php

class DataSetLongFreeText extends QuestionBaseDataSet
{

}
