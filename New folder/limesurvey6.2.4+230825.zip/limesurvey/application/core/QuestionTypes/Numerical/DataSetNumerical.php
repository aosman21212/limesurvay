<?php

class DataSetNumerical extends QuestionBaseDataSet
{

}
