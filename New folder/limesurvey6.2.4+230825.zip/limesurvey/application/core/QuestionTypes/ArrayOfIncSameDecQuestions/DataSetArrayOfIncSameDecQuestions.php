<?php

class DataSetArrayOfIncSameDecQuestions extends QuestionBaseDataSet
{

}
