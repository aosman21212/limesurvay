<?php

class DataSetLanguage extends QuestionBaseDataSet
{

}
