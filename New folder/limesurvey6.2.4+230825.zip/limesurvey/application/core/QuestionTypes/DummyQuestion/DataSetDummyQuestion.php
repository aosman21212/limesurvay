<?php

class DataSetDummyQuestion extends QuestionBaseDataSet
{

}
