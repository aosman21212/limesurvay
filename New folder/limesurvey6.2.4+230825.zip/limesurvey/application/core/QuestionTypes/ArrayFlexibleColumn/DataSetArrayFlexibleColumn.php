<?php

class DataSetArrayFlexibleColumn extends QuestionBaseDataSet
{

}
