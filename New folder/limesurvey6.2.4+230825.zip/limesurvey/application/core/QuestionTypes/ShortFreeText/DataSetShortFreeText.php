<?php

class DataSetShortFreeText extends QuestionBaseDataSet
{

}
