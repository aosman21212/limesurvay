<?php

class DataSetArray10ChoiceQuestion extends QuestionBaseDataSet
{

}
