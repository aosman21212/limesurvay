<?php

class DataSetHugeFreeText extends QuestionBaseDataSet
{

}
