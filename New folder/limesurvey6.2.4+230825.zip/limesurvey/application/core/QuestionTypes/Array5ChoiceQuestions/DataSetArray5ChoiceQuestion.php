<?php

class DataSetArray5ChoiceQuestion extends QuestionBaseDataSet
{

}
